# CLAUDE.md - AI Assistant Context

## Project Overview
Professional cryptocurrency trading bot for Bybit exchange with ML models, real-time monitoring, and secure cloud deployment on Fly.io.

## Current Status
- ✅ PostgreSQL database deployed and connected
- ✅ Mainnet API keys configured securely
- ✅ Production/testnet switch implemented (USE_MAINNET env var)
- ✅ Security measures (encryption, rate limiting, audit logging)
- ✅ ML models (Random Forest, XGBoost, Gradient Boosting)
- ✅ Data collection for historical training
- ✅ Telegram bot deployed (@bybit_danila_trading_bot)
- ✅ React dashboard deployed (https://bybit-danila-dashboard.fly.dev)
- ✅ GraphQL API at https://bybit-danila-bot.fly.dev/graphql

## Important Commands

### Local Testing
```bash
# Run tests
pytest tests/test_comprehensive.py

# Check linting
flake8 .

# Type checking
mypy .
```

### Deployment
```bash
# Deploy to Fly.io
fly deploy -a bybit-danila-bot

# Check status
fly status -a bybit-danila-bot

# View logs
fly logs -a bybit-danila-bot

# Switch to mainnet
fly secrets set USE_MAINNET=true -a bybit-danila-bot

# Switch to testnet
fly secrets set USE_MAINNET=false -a bybit-danila-bot
```

### Database Operations
```bash
# Run migration
python database/migrate_to_postgres.py

# Collect historical data
python data_collector.py

# Train ML models
python ml_trainer.py
```

## Key Files
- `config.py` - Configuration management (testnet/mainnet switch)
- `security/security_manager.py` - Security features
- `data_collector.py` - Historical data collection
- `ml_trainer.py` - ML model training
- `database/` - PostgreSQL models and migrations
- `dashboard/` - React frontend

## Environment Variables
- `USE_MAINNET` - Toggle between testnet (false) and mainnet (true)
- `BYBIT_MAINNET_API_KEY` - Mainnet API key
- `BYBIT_MAINNET_API_SECRET` - Mainnet API secret
- `DATABASE_URL` - PostgreSQL connection string
- `TELEGRAM_BOT_TOKEN` - Telegram bot token

## Known Issues
- WebSocket blocked by CloudFront in Singapore region (using REST fallback)
- Telegram bot may restart periodically (auto-recovery implemented)

## Next Steps
- Add Prometheus/Grafana monitoring
- Increase test coverage to 80%
- Create PWA service worker for offline dashboard
- Implement advanced trading strategies
- Add more ML model types (LSTM, Transformer)